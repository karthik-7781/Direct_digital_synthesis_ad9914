////#include "ad9914.h"
////
/////*
//// * SPI1 handle is defined in main.c.
//// */
////extern SPI_HandleTypeDef hspi1;
////
////const uint8_t CFR1Start[] = {0x00, 0x01, 0x00, 0x00};
////const uint8_t CFR2Start[] = {0x00, 0x80, 0x00, 0x00};
////const uint8_t CFR3Start[] = {0x00, 0x00, 0x19, 0x1C};
////const uint8_t CFR4Start[] = {0x00, 0x05, 0x21, 0x20};
////const uint8_t DACCAlEnable[] = {0x01, 0x05, 0x21, 0x20};
////
////
/////*
//// * Write one AD9914 register transaction.
//// *
//// * address: AD9914 register address
//// * data:    pointer to register data bytes
//// * length:  number of data bytes
//// *
//// * The AD9914 serial instruction byte uses:
//// * bit 7     = 0 for write
//// * bit 5:0   = register address
//// */
////HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address,
////                                       const uint8_t *data,
////                                       uint16_t length)
////{
////    HAL_StatusTypeDef status;
////    uint8_t instruction;
////
////    if ((data == NULL) || (length == 0U) || (address > 0x3FU))
////    {
////        return HAL_ERROR;
////    }
////
////    instruction = address & 0x3FU;
////
////    /* Begin transaction: active-low chip select */
////    HAL_GPIO_WritePin(DDS_CS_GPIO_Port,
////                      DDS_CS_Pin,
////                      GPIO_PIN_RESET);
////
////    /* Send the register instruction byte */
////    status = HAL_SPI_Transmit(&hspi1,
////                              &instruction,
////                              1U,
////                              HAL_MAX_DELAY);
////
////    /* Send register data only if the instruction succeeded */
////    if (status == HAL_OK)
////    {
////        status = HAL_SPI_Transmit(&hspi1,
////                                  (uint8_t *)data,
////                                  length,
////                                  HAL_MAX_DELAY);
////    }
////
////    /* End transaction */
////    HAL_GPIO_WritePin(DDS_CS_GPIO_Port,
////                      DDS_CS_Pin,
////                      GPIO_PIN_SET);
////
////    return status;
////}
////
////
/////*
//// * Transfer buffered DDS settings into active registers.
//// */
////void AD9914_IOUpdate(void)
////{
////    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port,
////                      DDS_IO_UPDATE_Pin,
////                      GPIO_PIN_RESET);
////
////    /*
////     * A short delay keeps the low phase explicit.
////     * The required pulse timing must be checked against
////     * the actual AD9914 system-clock configuration.
////     */
////    HAL_Delay(1);
////
////    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port,
////                      DDS_IO_UPDATE_Pin,
////                      GPIO_PIN_SET);
////
////    HAL_Delay(1);
////
////    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port,
////                      DDS_IO_UPDATE_Pin,
////                      GPIO_PIN_RESET);
////}
//
//
//#include "ad9914.h"
//#include <stddef.h>
//
///* SPI1 handle is defined in main.c */
//extern SPI_HandleTypeDef hspi1;
//
///*
// * Startup register values based on the ADI AD9914 external-control
// * example. Verify these settings against your board configuration
// * before applying power.
// */
//static const uint8_t CFR1Start[4] =
//{
//    0x00, 0x01, 0x00, 0x00
//	//git 0x00, 0x01 , 0x00 , 0x08
//	//software tool 00 01 2f 08
//};
//
//static const uint8_t CFR2Start[4] =
//{
//    0x00, 0x80, 0x09, 0x00
//	// 0x00, 0x0C, 0x29, 0x00
//	//git 0x00 , 0x80 , 0x00, 0x00
//	//software tool 00 80 09 08
//	//ai 00 80 09 00
//};
//
//static const uint8_t CFR3Start[4] =
//{
//    0x00, 0x00, 0x19, 0x1C
//	//software tool 00 00 19 00
//};
//
//static const uint8_t CFR4Start[4] =
//{
//    0x00, 0x05, 0x21, 0x20
//	//software tool 00 05 21 1c
//};
//
///* CFR4 bit 24 enables DAC calibration */
//static const uint8_t DACCAlEnable[4] =
//{
//    0x01, 0x05, 0x21, 0x20
//	//0x01, 0x05, 0x01, 0x20
//};
//
//
///*
// * Write an AD9914 register.
// *
// * Transaction:
// * CS low -> instruction byte -> register data -> CS high
// *
// * The data bytes are transmitted MSB first.
// */
//HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address,
//                                       const uint8_t *data,
//                                       uint16_t length)
//{
//    HAL_StatusTypeDef status;
//    uint8_t instruction;
//
//    if ((data == NULL) ||
//        (length == 0U) ||
//        (address > 0x3FU))
//    {
//        return HAL_ERROR;
//    }
//
//    /* Bit 7 = 0 for write; bits 5:0 contain the address */
//    instruction = address & 0x3FU;
//
//    HAL_GPIO_WritePin(DDS_CS_GPIO_Port,
//                      DDS_CS_Pin,
//                      GPIO_PIN_RESET);
//
//    status = HAL_SPI_Transmit(&hspi1,
//                              &instruction,
//                              1U,
//                              100U);
//
//    if (status == HAL_OK)
//    {
//        status = HAL_SPI_Transmit(&hspi1,
//                                  (uint8_t *)data,
//                                  length,
//                                  100U);
//    }
//
//    /* Always release CS */
//    HAL_GPIO_WritePin(DDS_CS_GPIO_Port,
//                      DDS_CS_Pin,
//                      GPIO_PIN_SET);
//
//    return status;
//}
//
//
///*
// * Apply buffered register values.
// * IO_UPDATE is activated by its rising edge.
// */
//void AD9914_IOUpdate(void)
//{
//    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port,
//                      DDS_IO_UPDATE_Pin,
//                      GPIO_PIN_RESET);
//
//    HAL_Delay(1U);
//
//    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port,
//                      DDS_IO_UPDATE_Pin,
//                      GPIO_PIN_SET);
//
//    HAL_Delay(1U);
//
//    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port,
//                      DDS_IO_UPDATE_Pin,
//                      GPIO_PIN_RESET);
//}
//
//
///*
// * Calculate the 32-bit DDS frequency tuning word.
// *
// * FTW = round((f_out / f_sysclk) * 2^32)
// *
// * For 100 MHz output and 2.4 GHz SYSCLK:
// * FTW = 0x0AAAAAAB
// */
//static void AD9914_CalculateFTW(uint8_t ftw[4])
//{
//    uint64_t ftw_value;
//
//    ftw_value =
//        ((AD9914_OUTPUT_HZ * (1ULL << 32)) +
//         (AD9914_SYSCLK_HZ / 2ULL))
//        / AD9914_SYSCLK_HZ;
//
//    ftw[0] = (uint8_t)(ftw_value >> 24);
//    ftw[1] = (uint8_t)(ftw_value >> 16);
//    ftw[2] = (uint8_t)(ftw_value >> 8);
//    ftw[3] = (uint8_t)ftw_value;
//}
//
//
///*
// * Configure the AD9914 and program a 100 MHz single-tone frequency.
// *
// * Call once after MX_GPIO_Init() and MX_SPI1_Init().
// */
//HAL_StatusTypeDef AD9914_Configure100MHz(void)
//{
//    HAL_StatusTypeDef status;
//    uint8_t ftw[4];
//
//    /* Step 1: Configure the control registers */
//    status = AD9914_WriteRegister(AD9914_CFR1_ADDR,
//                                  CFR1Start,
//                                  sizeof(CFR1Start));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_CFR2_ADDR,
//                                  CFR2Start,
//                                  sizeof(CFR2Start));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_CFR3_ADDR,
//                                  CFR3Start,
//                                  sizeof(CFR3Start));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_CFR4_ADDR,
//                                  CFR4Start,
//                                  sizeof(CFR4Start));
//    if (status != HAL_OK) return status;
//
//    AD9914_IOUpdate();
//
//    /* Step 2: Enable DAC calibration */
//    status = AD9914_WriteRegister(AD9914_CFR4_ADDR,
//                                  DACCAlEnable,
//                                  sizeof(DACCAlEnable));
//    if (status != HAL_OK) return status;
//
//    AD9914_IOUpdate();
//
//    /* Allow time for the DAC calibration procedure */
//    HAL_Delay(1U);
//
//    /* Step 3: Clear the DAC calibration enable bit */
//    status = AD9914_WriteRegister(AD9914_CFR4_ADDR,
//                                  CFR4Start,
//                                  sizeof(CFR4Start));
//    if (status != HAL_OK) return status;
//
//    AD9914_IOUpdate();
//
//    /* Step 4: Calculate and write the 100 MHz FTW */
//    AD9914_CalculateFTW(ftw);
//
//    status = AD9914_WriteRegister(AD9914_PROFILE0_FTW,
//                                  ftw,
//                                  sizeof(ftw));
//    if (status != HAL_OK) return status;
//
//    /* Step 5: Activate the frequency setting */
//    AD9914_IOUpdate();
//
//    return HAL_OK;
//}



/* ----------------- start -------------------*/
//#include "ad9914.h"
//#include <stddef.h>
//#include <string.h>
//
///* SPI1 handle defined in main.c */
//extern SPI_HandleTypeDef hspi1;
//
///*
// * CFR1 (0x00):
// * - Byte 1 (0x01): Bit 16 = 1 (Select Sine wave output)
// * - Byte 3 (0x02): Bit 1  = 1 (SDIO Input-Only mode for unidirectional MOSI operation)
// */
//static const uint8_t CFR1Start[4] = { 0x00, 0x01, 0x00, 0x02 };
//
///*
// * CFR2 (0x01):
// * - Byte 1 (0x80): Bit 23 = 1 (Profile Mode Enable - required for Profile 0 output)
// * - Byte 2 (0x09): Bit 11 = 1 (SYNC_CLK output enabled), Bit 8 = 1 (Required factory default)
// */
////static const uint8_t CFR2Start[4] = { 0x00, 0x80, 0x09, 0x00 }; //without DRG
//
//static const uint8_t CFG2Start[4] = {0x00, 0x0D, 0x08, 0x00};
//
///*
// * CFR3 (0x02):
// * - Bit 18 = 0 (Internal PLL bypassed for direct 500 MHz REF_CLK input)
// */
//static const uint8_t CFR3Start[4] = { 0x00, 0x00, 0x19, 0x1C };
//
///*
// * CFR4 (0x03):
// * - Factory default DAC configuration (0x00052120)
// * - DACCalEnable sets Bit 24 = 1 (0x01052120) to run internal DAC calibration
// */
//static const uint8_t CFR4Start[4]    = { 0x00, 0x05, 0x21, 0x20 };
//static const uint8_t DACCalEnable[4] = { 0x01, 0x05, 0x21, 0x20 };
//
///*
// * Profile 0 Phase/Amplitude (0x0C):
// * - Bits [27:16] = 0xFFF (Full-scale DAC amplitude)
// * - Bits [15:0]  = 0x0000 (0 degree phase offset)
// */
//static const uint8_t Profile0AmpStart[4] = { 0x0F, 0xFF, 0x00, 0x00 };
//
//static const uint8_t digital_ramp_lower_register[4] = {0x05, 0x1E, 0xB8, 0x52};
//
//static const uint8_t digital_ramp_upper_register[4] = {0x38, 0x51, 0xEB, 0x85};
//
//static const uint8_t raising_digital_ramp_step_size_register[4] = {0x00, 0x00, 0x86, 0x38};
//
//static const uint8_t falling_digital_ramp_step_size_register[4] = {0x33, 0x33, 0x33, 0x33};
//
//static const uint8_t digital_ramp_rate_register[4] = {0x00, 0x01, 0x00, 0x19};
//
///*
// * Write a 32-bit AD9914 register in a single 5-byte SPI frame:
// * [1-byte Instruction] + [4-byte Data (MSB first)]
// */
//
////static const uint8_t CFR1Start[4] = { 0x00, 0x01, 0x00, 0x0A }; /* 0x08 (PC default) | 0x02 (SDIO input-only) */
////static const uint8_t CFR2Start[4] = { 0x00, 0x80, 0x09, 0x00 };
////static const uint8_t CFR3Start[4] = { 0x00, 0x00, 0x19, 0x1C };
////static const uint8_t CFR4Start[4] = { 0x00, 0x05, 0x21, 0x20 };
//HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address,
//                                       const uint8_t *data,
//                                       uint16_t length)
//{
//    HAL_StatusTypeDef status;
//    uint8_t tx_buf[5];
//
//    if ((data == NULL) || (length == 0U) || (length > 4U) || (address > 0x3FU))
//    {
//        return HAL_ERROR;
//    }
//
//    /* Bit 7 = 0 (Write operation), Bits [5:0] = Register Address */
//    tx_buf[0] = address & 0x3FU;
//    memcpy(&tx_buf[1], data, length);
//
//    HAL_GPIO_WritePin(DDS_CS_GPIO_Port, DDS_CS_Pin, GPIO_PIN_RESET);
//
//    /* Single transmit call keeps SPE=1 across all 40 clock edges */
//    status = HAL_SPI_Transmit(&hspi1, tx_buf, length + 1U, 100U);
//
//    HAL_GPIO_WritePin(DDS_CS_GPIO_Port, DDS_CS_Pin, GPIO_PIN_SET);
//
//    return status;
//}
//
///*
// * Pulse IO_UPDATE High to latch buffered SPI registers into the active DDS core.
// */
//void AD9914_IOUpdate(void)
//{
//    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port, DDS_IO_UPDATE_Pin, GPIO_PIN_RESET);
//    HAL_Delay(1U);
//
//    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port, DDS_IO_UPDATE_Pin, GPIO_PIN_SET);
//    HAL_Delay(1U);
//
//    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port, DDS_IO_UPDATE_Pin, GPIO_PIN_RESET);
//    HAL_Delay(1U);
//}
//
///*
// * Calculate 32-bit Frequency Tuning Word:
// * FTW = round((100 MHz / 500 MHz) * 2^32) = 0x33333333
// */
//static void AD9914_CalculateFTW(uint8_t ftw[4])
//{
//    uint64_t ftw_value =
//        ((AD9914_OUTPUT_HZ * (1ULL << 32)) + (AD9914_SYSCLK_HZ / 2ULL))
//        / AD9914_SYSCLK_HZ;
//
//    ftw[0] = (uint8_t)(ftw_value >> 24);
//    ftw[1] = (uint8_t)(ftw_value >> 16);
//    ftw[2] = (uint8_t)(ftw_value >> 8);
//    ftw[3] = (uint8_t)ftw_value;
//}
//
///*
// * Initialize AD9914, calibrate internal DAC, and output 100 MHz on Profile 0.
// */
//HAL_StatusTypeDef AD9914_Configure100MHz(void)
//{
//    HAL_StatusTypeDef status;
//    uint8_t ftw[4];
//
//    /* Step 1: Write Control Function Registers CFR1 - CFR4 */
//    status = AD9914_WriteRegister(AD9914_CFR1_ADDR, CFR1Start, sizeof(CFR1Start));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_CFR2_ADDR, CFR2Start, sizeof(CFR2Start));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_CFR3_ADDR, CFR3Start, sizeof(CFR3Start));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_CFR4_ADDR, CFR4Start, sizeof(CFR4Start));
//    if (status != HAL_OK) return status;
//
//    AD9914_IOUpdate();
//
//    /* Step 2: Enable DAC calibration (CFR4[24] = 1) */
//    status = AD9914_WriteRegister(AD9914_CFR4_ADDR, DACCalEnable, sizeof(DACCalEnable));
//    if (status != HAL_OK) return status;
//
//    AD9914_IOUpdate();
//    HAL_Delay(2U); /* Wait > 1 ms for internal DAC calibration to complete */
//
//    /* Step 3: Clear DAC calibration bit (CFR4[24] = 0) */
//    status = AD9914_WriteRegister(AD9914_CFR4_ADDR, CFR4Start, sizeof(CFR4Start));
//    if (status != HAL_OK) return status;
//
//    AD9914_IOUpdate();
//
//    /* Step 4: Write Profile 0 Frequency Tuning Word (0x0B) and Full-Scale Amplitude (0x0C) */
//    AD9914_CalculateFTW(ftw);
//
//    status = AD9914_WriteRegister(AD9914_PROFILE0_FTW, ftw, sizeof(ftw));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_PROFILE0_PHASE_AMP, Profile0AmpStart, sizeof(Profile0AmpStart));
//    if (status != HAL_OK) return status;
//
//    /* Step 5: Latch Profile 0 into DDS core */
//    AD9914_IOUpdate();
//
//    return HAL_OK;
//}
//
//HAL_StatusTypeDef AD9914_ConfigureSweep(void)
//{
//	HAL_StatusTypeDef status;
//
//	/* --------------configuring registers -----------------*/
//
//	status = AD9914_WriteRegister(AD9914_CFR1_ADDR, CFR1Start, sizeof(CFR1Start));
//	if(status != HAL_OK) return;
//
//	status = AD9914_WriteRegister(AD9914_CFR2_ADDR, CFG2Start, sizeof(CFG2Start));
//	if(status != HAL_OK) return;
//
//	status = AD9914_WriteRegister(AD9914_CFR3_ADDR, CFR3Start, sizeof(CFR3Start));
//	if(status != HAL_OK) return;
//
//	status = AD9914_WriteRegister(AD9914_CFR4_ADDR, CFR4Start, sizeof(CFR4Start));
//	if(status != HAL_OK) return;
//
//	AD9914_IOUpdate();
//
//	/* ----------------- configure DAC Registers ----------*/
//
//	status = AD9914_WriteRegister(AD9914_DR_lower_limit, digital_ramp_lower_register, sizeof(digital_ramp_lower_register));
//	if(status != HAL_OK) return;
//
//	status = AD9914_WriteRegister(AD9914_DR_upper_limit, digital_ramp_upper_register, sizeof(digital_ramp_upper_register));
//	if(status != HAL_OK) return;
//
//	status = AD9914_WriteRegister(AD9914_Raising_DR_SS, raising_digital_ramp_step_size_register, sizeof(raising_digital_ramp_step_size_register));
//	if(status != HAL_OK) return;
//
//	status = AD9914_WriteRegister(AD9914_Falling_DR_SS, falling_digital_ramp_step_size_register, sizeof(falling_digital_ramp_step_size_register));
//	if(status != HAL_OK) return;
//
//	status = AD9914_WriteRegister(AD9914_DR_Rate, digital_ramp_rate_register, sizeof(digital_ramp_rate_register));
//	if(status != HAL_OK) return;
//
//	AD9914_IOUpdate();
//
//	/* --------------------DAC calibration -----------------*/
//	status = AD9914_WriteRegister(AD9914_CFR4_ADDR, DACCalEnable, sizeof(CFR4Start));
//	if(status != HAL_OK) return;
//
//	AD9914_IOUpdate();
//
//	HAL_Delay(1U);
//
//	/* -------------------clear DAC calibration bit -------------*/
//	status = AD9914_WriteRegister(AD9914_CFR4_ADDR, CFR4Start, sizeof(CFR4Start));
//
//	AD9914_IOUpdate();
//
//}
/* ---------------- end -----------------------*/


///* ----------------- DRG start ----------------*/
//
//#include "ad9914.h"
//#include <stddef.h>
//#include <string.h>
//
//extern SPI_HandleTypeDef hspi1;
//
///* CFR1 (0x00): Sine output (Bit 16), Ext PD mode (Bit 3), SDIO Input-Only (Bit 1) */
//static const uint8_t CFR1Start[4] = { 0x00, 0x01, 0x00, 0x0A };
//
///* CFR2 (0x01) for Continuous Sweep: Profile=1, DRG=1, NoDwell_H=1, NoDwell_L=1 -> 0x008E0900 */
//static const uint8_t CFR2Sweep[4] = { 0x00, 0x8E, 0x09, 0x00 };
//
///* CFR3 (0x02): PLL bypassed for direct 500 MHz reference clock */
//static const uint8_t CFR3Start[4] = { 0x00, 0x00, 0x19, 0x1C };
//
///* CFR4 (0x03): Factory defaults & DAC calibration enable */
//static const uint8_t CFR4Start[4]    = { 0x00, 0x05, 0x21, 0x20 };
//static const uint8_t DACCalEnable[4] = { 0x01, 0x05, 0x21, 0x20 };
//
///* Profile 0 Phase/Amplitude (0x0C): Full-scale amplitude (0xFFF) */
//static const uint8_t Profile0AmpStart[4] = { 0x0F, 0xFF, 0x00, 0x00 };
//
///*
// * Sweep Parameters: 10 MHz -> 110 MHz in 30 us (f_SYSCLK = 500 MHz)
// * - 0x04 Lower Limit: 10 MHz  = 0x051EB852
// * - 0x05 Upper Limit: 110 MHz = 0x3851EB85
// * - 0x06 Rising Step: 160 kHz = 0x0014F8B6 (625 steps)
// * - 0x07 Falling Step: 100 MHz = 0x33333333 (1-step instant sawtooth flyback)
// * - 0x08 Ramp Rate:   P-=1 tick (48 ns), P+=1 tick (48 ns) -> 0x00010001
// */
//static const uint8_t SweepLowerLimit[4]  = { 0x05, 0x1E, 0xB8, 0x52 };
//static const uint8_t SweepUpperLimit[4]  = { 0x38, 0x51, 0xEB, 0x85 };
//static const uint8_t SweepRisingStep[4]  = { 0x00, 0x14, 0xF8, 0xB6 };
//static const uint8_t SweepFallingStep[4] = { 0x33, 0x33, 0x33, 0x33 };
//static const uint8_t SweepRampRate[4]    = { 0x00, 0x01, 0x00, 0x01 };
//
//HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address,
//                                       const uint8_t *data,
//                                       uint16_t length)
//{
//    HAL_StatusTypeDef status;
//    uint8_t tx_buf[5];
//
//    if ((data == NULL) || (length == 0U) || (length > 4U) || (address > 0x3FU))
//    {
//        return HAL_ERROR;
//    }
//
//    tx_buf[0] = address & 0x3FU;
//    memcpy(&tx_buf[1], data, length);
//
//    HAL_GPIO_WritePin(DDS_CS_GPIO_Port, DDS_CS_Pin, GPIO_PIN_RESET);
//    status = HAL_SPI_Transmit(&hspi1, tx_buf, length + 1U, 100U);
//    HAL_GPIO_WritePin(DDS_CS_GPIO_Port, DDS_CS_Pin, GPIO_PIN_SET);
//
//    return status;
//}
//
//void AD9914_IOUpdate(void)
//{
//    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port, DDS_IO_UPDATE_Pin, GPIO_PIN_RESET);
//    HAL_Delay(1U);
//    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port, DDS_IO_UPDATE_Pin, GPIO_PIN_SET);
//    HAL_Delay(1U);
//    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port, DDS_IO_UPDATE_Pin, GPIO_PIN_RESET);
//    HAL_Delay(1U);
//}
//
//HAL_StatusTypeDef AD9914_ConfigureSweep_10_to_110MHz_30us(void)
//{
//    HAL_StatusTypeDef status;
//
//    /* 1. Write Control Function Registers CFR1 through CFR4 */
//    status = AD9914_WriteRegister(AD9914_CFR1_ADDR, CFR1Start, sizeof(CFR1Start));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_CFR2_ADDR, CFR2Sweep, sizeof(CFR2Sweep));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_CFR3_ADDR, CFR3Start, sizeof(CFR3Start));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_CFR4_ADDR, CFR4Start, sizeof(CFR4Start));
//    if (status != HAL_OK) return status;
//
//    AD9914_IOUpdate();
//
//    /* 2. Execute Internal DAC Calibration */
//    status = AD9914_WriteRegister(AD9914_CFR4_ADDR, DACCalEnable, sizeof(DACCalEnable));
//    if (status != HAL_OK) return status;
//
//    AD9914_IOUpdate();
//    HAL_Delay(2U);
//
//    status = AD9914_WriteRegister(AD9914_CFR4_ADDR, CFR4Start, sizeof(CFR4Start));
//    if (status != HAL_OK) return status;
//
//    AD9914_IOUpdate();
//
//    /* 3. Program Digital Ramp Generator (DRG) registers 0x04 to 0x08 */
//    status = AD9914_WriteRegister(AD9914_DRG_LOWER_LIMIT, SweepLowerLimit, sizeof(SweepLowerLimit));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_DRG_UPPER_LIMIT, SweepUpperLimit, sizeof(SweepUpperLimit));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_DRG_RISING_STEP, SweepRisingStep, sizeof(SweepRisingStep));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_DRG_FALLING_STEP, SweepFallingStep, sizeof(SweepFallingStep));
//    if (status != HAL_OK) return status;
//
//    status = AD9914_WriteRegister(AD9914_DRG_RAMP_RATE, SweepRampRate, sizeof(SweepRampRate));
//    if (status != HAL_OK) return status;
//
//    /* 4. Set Profile 0 Amplitude to Full-Scale */
//    status = AD9914_WriteRegister(AD9914_PROFILE0_PHASE_AMP, Profile0AmpStart, sizeof(Profile0AmpStart));
//    if (status != HAL_OK) return status;
//
//    /* 5. Latch all parameters and begin the continuous sweep */
//    AD9914_IOUpdate();
//
//    return HAL_OK;
//}
//
///* ----------------- DRG end -------------------*/

/* --------------------DRG pulses start ------------*/

#include "ad9914.h"
#include <stddef.h>
#include <string.h>

extern SPI_HandleTypeDef hspi1;

/* CFR1 (0x00): Sine (Bit 16), Ext OSK (Bit 9), OSK Enable (Bit 8), Ext PD (Bit 3), SDIO Input-Only (Bit 1) */
static const uint8_t CFR1_Pulsed[4] = { 0x00, 0x01, 0x03, 0x0A };

/* CFR2 (0x01): Profile=1, DRG=1, No-Dwell High=1, No-Dwell Low=0 (Triggered One-Shot) -> 0x008C0900 */
static const uint8_t CFR2_OneShot[4] = { 0x00, 0x8C, 0x09, 0x00 };

/* CFR3 (0x02): PLL bypassed for direct 500 MHz reference clock */
static const uint8_t CFR3Start[4] = { 0x00, 0x00, 0x19, 0x1C };

/* CFR4 (0x03): Factory defaults & calibration */
static const uint8_t CFR4Start[4]    = { 0x00, 0x05, 0x21, 0x20 };
static const uint8_t DACCalEnable[4] = { 0x01, 0x05, 0x21, 0x20 };

/* Profile 0 Amplitude (0x0C): Full Scale (0xFFF) */
static const uint8_t Profile0AmpStart[4] = { 0x0F, 0xFF, 0x00, 0x00 };

/* Limits common to both sweeps: 10 MHz to 110 MHz */
static const uint8_t SweepLowerLimit[4]  = { 0x05, 0x1E, 0xB8, 0x52 }; /* 10 MHz  0x05, 0x1E, 0xB8, 0x52 */
static const uint8_t SweepUpperLimit[4]  = { 0x38, 0x51, 0xEB, 0x85 }; /* 110 MHz 0x38, 0x51, 0xEB, 0x85 */
static const uint8_t SweepFallingStep[4] = { 0x33, 0x33, 0x33, 0x33 }; /* Instant flyback */
static const uint8_t SweepRampRate[4]    = { 0x00, 0x01, 0x00, 0x01 }; /* P-=1, P+=1 (48 ns) 0x00, 0x01, 0x00, 0x01*/

/* Shorter Pulse: 10 steps of 10 MHz = 0.480 us */
static const uint8_t ShortRisingStep[4]  = { 0x05, 0x1E, 0xB8, 0x52 };

/* Longer Pulse: 250 steps of 400 kHz = 12.000 us */
static const uint8_t LongRisingStep[4]   = { 0x00, 0x34, 0x6D, 0xC6 };

HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address, const uint8_t *data, uint16_t length)
{
    HAL_StatusTypeDef status;
    uint8_t tx_buf[5];

    if ((data == NULL) || (length == 0U) || (length > 4U) || (address > 0x3FU))
    {
        return HAL_ERROR;
    }

    tx_buf[0] = address & 0x3FU;
    memcpy(&tx_buf[1], data, length);

    HAL_GPIO_WritePin(DDS_CS_GPIO_Port, DDS_CS_Pin, GPIO_PIN_RESET);
    status = HAL_SPI_Transmit(&hspi1, tx_buf, length + 1U, 100U);
    HAL_GPIO_WritePin(DDS_CS_GPIO_Port, DDS_CS_Pin, GPIO_PIN_SET);

    return status;
}

void AD9914_IOUpdate(void)
{
    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port, DDS_IO_UPDATE_Pin, GPIO_PIN_RESET);
    HAL_Delay(1U);
    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port, DDS_IO_UPDATE_Pin, GPIO_PIN_SET);
    HAL_Delay(1U);
    HAL_GPIO_WritePin(DDS_IO_UPDATE_GPIO_Port, DDS_IO_UPDATE_Pin, GPIO_PIN_RESET);
    HAL_Delay(1U);
}

/* Nanosecond/Microsecond delay using Cortex-M7 DWT Cycle Counter */
static void DWT_Delay_Cycles(uint32_t cycles)
{
    uint32_t start = DWT->CYCCNT;
    while ((DWT->CYCCNT - start) < cycles);
}

HAL_StatusTypeDef AD9914_Init_PulsedChirp(void)
{
    HAL_StatusTypeDef status;

    /* Initialize DWT counter for sub-microsecond timing */
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

    /* Ensure trigger is low initially (DDS off) */
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);

    status = AD9914_WriteRegister(AD9914_CFR1_ADDR, CFR1_Pulsed, sizeof(CFR1_Pulsed));
    if (status != HAL_OK) return status;

    status = AD9914_WriteRegister(AD9914_CFR2_ADDR, CFR2_OneShot, sizeof(CFR2_OneShot));
    if (status != HAL_OK) return status;

    status = AD9914_WriteRegister(AD9914_CFR3_ADDR, CFR3Start, sizeof(CFR3Start));
    if (status != HAL_OK) return status;

    status = AD9914_WriteRegister(AD9914_CFR4_ADDR, CFR4Start, sizeof(CFR4Start));
    if (status != HAL_OK) return status;

    AD9914_IOUpdate();

    /* DAC Calibration */
    status = AD9914_WriteRegister(AD9914_CFR4_ADDR, DACCalEnable, sizeof(DACCalEnable));
    if (status != HAL_OK) return status;
    AD9914_IOUpdate();
    HAL_Delay(2U);
    status = AD9914_WriteRegister(AD9914_CFR4_ADDR, CFR4Start, sizeof(CFR4Start));
    if (status != HAL_OK) return status;
    AD9914_IOUpdate();

    /* Load lower/upper limits, falling step, ramp rate, full amplitude */
    status = AD9914_WriteRegister(AD9914_DRG_LOWER_LIMIT, SweepLowerLimit, sizeof(SweepLowerLimit));
    if (status != HAL_OK) return status;
    status = AD9914_WriteRegister(AD9914_DRG_UPPER_LIMIT, SweepUpperLimit, sizeof(SweepUpperLimit));
    if (status != HAL_OK) return status;
    status = AD9914_WriteRegister(AD9914_DRG_FALLING_STEP, SweepFallingStep, sizeof(SweepFallingStep));
    if (status != HAL_OK) return status;
    status = AD9914_WriteRegister(AD9914_DRG_RAMP_RATE, SweepRampRate, sizeof(SweepRampRate));
    if (status != HAL_OK) return status;
    status = AD9914_WriteRegister(AD9914_PROFILE0_PHASE_AMP, Profile0AmpStart, sizeof(Profile0AmpStart));
    if (status != HAL_OK) return status;

    AD9914_IOUpdate();
    return HAL_OK;
}

HAL_StatusTypeDef AD9914_SetShorterPulseParams(void)
{
    HAL_StatusTypeDef status;
    status = AD9914_WriteRegister(AD9914_DRG_RISING_STEP, ShortRisingStep, sizeof(ShortRisingStep));
    if (status != HAL_OK) return status;
    AD9914_IOUpdate();
    return HAL_OK;
}

HAL_StatusTypeDef AD9914_SetLongerPulseParams(void)
{
    HAL_StatusTypeDef status;
    status = AD9914_WriteRegister(AD9914_DRG_RISING_STEP, LongRisingStep, sizeof(LongRisingStep));
    if (status != HAL_OK) return status;
    AD9914_IOUpdate();
    return HAL_OK;
}

void AD9914_Run128PulseSequence(void)
{
    /* Calculate DWT cycle counts based on SystemCoreClock */
    uint32_t short_tx_cycles   = (SystemCoreClock / 1000000U) * 480U / 1000U;     /* 0.480 us */
    uint32_t short_wait_cycles = (SystemCoreClock / 1000000U) * 161504U / 1000U;  /* 161.504 us */
    uint32_t long_tx_cycles    = (SystemCoreClock / 1000000U) * 12U;              /* 12 us */
    uint32_t long_wait_cycles  = (SystemCoreClock / 1000000U) * 160800U / 1000U;  /* 160.8 us */

    /* Phase 1: 64 Shorter Pulses */
    AD9914_SetShorterPulseParams();
    for (int i = 0; i < 64; i++)
    {
        /* Pulse Trigger High: RF ON + Sweep runs 10 -> 110 MHz */
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
        DWT_Delay_Cycles(short_tx_cycles);

        /* Pulse Trigger Low: RF OFF (Muted) + Listen window */
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);
        DWT_Delay_Cycles(short_wait_cycles);
    }

    /* Phase 2: 64 Longer Pulses */
    AD9914_SetLongerPulseParams();
    for (int i = 0; i < 64; i++)
    {
        /* Pulse Trigger High: RF ON + Sweep runs 10 -> 110 MHz */
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
        DWT_Delay_Cycles(long_tx_cycles);

        /* Pulse Trigger Low: RF OFF (Muted) + Listen window */
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);
        DWT_Delay_Cycles(long_wait_cycles);
    }
}
/* --------------------DRG pulses end -------------*/
