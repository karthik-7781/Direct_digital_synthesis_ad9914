////#ifndef AD9914_H
////#define AD9914_H
////
////#include "main.h"
////#include <stdint.h>
////
////HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address,
////                                       const uint8_t *data,
////                                       uint16_t length);
////
////void AD9914_IOUpdate(void);
////
////#endif
//
//
//#ifndef AD9914_H
//#define AD9914_H
//
//#include "main.h"
//#include <stdint.h>
//
///* AD9914 serial register addresses */
//#define AD9914_CFR1_ADDR       0x00U
//#define AD9914_CFR2_ADDR       0x01U
//#define AD9914_CFR3_ADDR       0x02U
//#define AD9914_CFR4_ADDR       0x03U
//#define AD9914_PROFILE0_FTW    0x0BU
//
///*
// * DDS system clock, not the STM32 CPU clock.
// * This value must match the actual AD9914 SYSCLK.
// */
//#define AD9914_SYSCLK_HZ       500000000ULL
//#define AD9914_OUTPUT_HZ       100000000ULL
//
//HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address,
//                                       const uint8_t *data,
//                                       uint16_t length);
//
//void AD9914_IOUpdate(void);
//
//HAL_StatusTypeDef AD9914_Configure100MHz(void);
//
//#endif


/* ---------------start -------------------*/

//#ifndef AD9914_H
//#define AD9914_H
//
//#include "main.h"
//#include <stdint.h>
//
///* AD9914 serial register addresses */
//#define AD9914_CFR1_ADDR          0x00U
//#define AD9914_CFR2_ADDR          0x01U
//#define AD9914_CFR3_ADDR          0x02U
//#define AD9914_CFR4_ADDR          0x03U
//#define AD9914_PROFILE0_FTW       0x0BU
//#define AD9914_PROFILE0_PHASE_AMP 0x0CU
//#define AD9914_DR_lower_limit     0x04U
//#define AD9914_DR_upper_limit     0x05U
//#define AD9914_Raising_DR_SS	  0x06U
//#define AD9914_Falling_DR_SS      0x07U
//#define AD9914_DR_Rate			  0x08U
//
///*
// * DDS system clock (500 MHz external REF_CLK with internal PLL bypassed)
// * and target output frequency (100 MHz).
// */
//#define AD9914_SYSCLK_HZ          500000000ULL
//#define AD9914_OUTPUT_HZ          100000000ULL
//
//HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address,
//                                       const uint8_t *data,
//                                       uint16_t length);
//
//void AD9914_IOUpdate(void);
//
//HAL_StatusTypeDef AD9914_Configure100MHz(void);
//
//HAL_StatusTypeDef AD9914_ConfigureSweep(void);
//
//#endif /* AD9914_H */


/* ------------end --------------------*/

///* ----------------- DRG start ----------------*/
//#ifndef AD9914_H
//#define AD9914_H
//
//#include "main.h"
//#include <stdint.h>
//
///* AD9914 serial register addresses */
//#define AD9914_CFR1_ADDR          0x00U
//#define AD9914_CFR2_ADDR          0x01U
//#define AD9914_CFR3_ADDR          0x02U
//#define AD9914_CFR4_ADDR          0x03U
//#define AD9914_DRG_LOWER_LIMIT    0x04U
//#define AD9914_DRG_UPPER_LIMIT    0x05U
//#define AD9914_DRG_RISING_STEP    0x06U
//#define AD9914_DRG_FALLING_STEP   0x07U
//#define AD9914_DRG_RAMP_RATE      0x08U
//#define AD9914_PROFILE0_FTW       0x0BU
//#define AD9914_PROFILE0_PHASE_AMP 0x0CU
//
///* DDS clock reference */
//#define AD9914_SYSCLK_HZ          500000000ULL
//
//HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address,
//                                       const uint8_t *data,
//                                       uint16_t length);
//
//void AD9914_IOUpdate(void);
//
///* Single-tone 100 MHz generator */
//HAL_StatusTypeDef AD9914_Configure100MHz(void);
//
///* Linear Sweep: 10 MHz to 110 MHz in 30 us */
//HAL_StatusTypeDef AD9914_ConfigureSweep_10_to_110MHz_30us(void);
//
//#endif /* AD9914_H */
//
///* ----------------- DRG end -------------------*/

/* ------------------DRG pulses start ---------------*/

#ifndef AD9914_H
#define AD9914_H

#include "main.h"
#include <stdint.h>

#define AD9914_CFR1_ADDR          0x00U
#define AD9914_CFR2_ADDR          0x01U
#define AD9914_CFR3_ADDR          0x02U
#define AD9914_CFR4_ADDR          0x03U
#define AD9914_DRG_LOWER_LIMIT    0x04U
#define AD9914_DRG_UPPER_LIMIT    0x05U
#define AD9914_DRG_RISING_STEP    0x06U
#define AD9914_DRG_FALLING_STEP   0x07U
#define AD9914_DRG_RAMP_RATE      0x08U
#define AD9914_PROFILE0_FTW       0x0BU
#define AD9914_PROFILE0_PHASE_AMP 0x0CU

#define AD9914_SYSCLK_HZ          500000000ULL

HAL_StatusTypeDef AD9914_WriteRegister(uint8_t address, const uint8_t *data, uint16_t length);
void AD9914_IOUpdate(void);

/* Base setup and pulse functions */
HAL_StatusTypeDef AD9914_Init_PulsedChirp(void);
HAL_StatusTypeDef AD9914_SetShorterPulseParams(void);
HAL_StatusTypeDef AD9914_SetLongerPulseParams(void);
void AD9914_Run128PulseSequence(void);

#endif /* AD9914_H */

/* ------------------DRG pulses end ----------------*/
